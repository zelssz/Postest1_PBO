package com.mycompany.koleksifashion;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FashionApp {

    // ====== Model data sederhana ======
    static class Item {
        int id;
        String nama, kategori, ukuran, warna, brand;
        int tahun;
        Item(int id, String nama, String kategori, String ukuran, String warna, String brand, int tahun) {
            this.id = id; this.nama = nama; this.kategori = kategori; this.ukuran = ukuran;
            this.warna = warna; this.brand = brand; this.tahun = tahun;
        }
    }

    // ====== Koleksi ======
    static final List<Item> katalog = new ArrayList<>();
    static int nextId = 1;

    public static void main(String[] args) {
        seed10Item(); // data awal

        Scanner in = new Scanner(System.in);
        while (true) {
            clearScreen();
            printBanner();
            printMainMenu();

            System.out.print("Pilih menu [1-7] > ");
            String p = in.nextLine().trim();

            switch (p) {
                case "1" -> {
                    clearScreen(); sectionTitle("TAMBAHKAN KOLEKSI ITEM");
                    tambahItem(in); pause(in);
                }
                case "2" -> {
                    clearScreen(); sectionTitle("DAFTAR KOLEKSI");
                    tampilkanTabel(katalog); pause(in);
                }
                case "3" -> {
                    clearScreen(); sectionTitle("CARI (ID/NAMA)");
                    cari(in); pause(in);
                }
                case "4" -> {
                    clearScreen(); sectionTitle("UBAH Data Koleksi");
                    ubah(in); pause(in);
                }
                case "5" -> {
                    clearScreen(); sectionTitle("HAPUS Koleksi");
                    hapus(in); pause(in);
                }
                case "6" -> {
                    clearScreen(); sectionTitle("FILTER KOLEKSI");
                    filterMenu(in); pause(in);
                }
                case "7" -> {
                    clearScreen(); boxInfo("Terima kasih. Program selesai."); return;
                }
                default -> { boxInfo("Menu tidak valid. Coba lagi."); pause(in); }
            }
        }
    }

    // ====== CRUD ======
    static void tambahItem(Scanner in) {
        String nama = inputWajib(in, "Nama");
        String kategori = inputWajib(in, "Kategori");
        String ukuran = inputWajib(in, "Ukuran");
        String warna = inputWajib(in, "Warna");
        String brand = inputWajib(in, "Brand/Desainer");
        int tahun = inputAngkaNonNegatif(in, "Tahun Koleksi");

        katalog.add(new Item(nextId++, nama, kategori, ukuran, warna, brand, tahun));
        boxInfo("Item ditambahkan.");
    }

    static void cari(Scanner in) {
        System.out.print("Masukkan ID atau Nama Produk: ");
        String q = in.nextLine().trim();

        List<Item> hasil = new ArrayList<>();
        try {
            int id = Integer.parseInt(q);
            for (Item it : katalog) if (it.id == id) hasil.add(it);
        } catch (NumberFormatException e) {
            for (Item it : katalog)
                if (it.nama.toLowerCase().contains(q.toLowerCase())) hasil.add(it);
        }

        if (hasil.isEmpty()) boxInfo("Masukkan ID/Nama Produk.");
        else tampilkanTabel(hasil);
    }

    static void ubah(Scanner in) {
        int id = inputAngkaNonNegatif(in, "Masukkan ID");
        Item it = findById(id);
        if (it == null) { boxInfo("ID tidak ditemukan."); return; }

        System.out.println("(Biarkan kosong lalu tekan Enter untuk mempertahankan sebelumnya)");

        System.out.print("Nama [" + it.nama + "]: ");
        String v = in.nextLine().trim(); if (!v.isEmpty()) it.nama = v;

        System.out.print("Kategori [" + it.kategori + "]: ");
        v = in.nextLine().trim(); if (!v.isEmpty()) it.kategori = v;

        System.out.print("Ukuran [" + it.ukuran + "]: ");
        v = in.nextLine().trim(); if (!v.isEmpty()) it.ukuran = v;

        System.out.print("Warna [" + it.warna + "]: ");
        v = in.nextLine().trim(); if (!v.isEmpty()) it.warna = v;

        System.out.print("Brand [" + it.brand + "]: ");
        v = in.nextLine().trim(); if (!v.isEmpty()) it.brand = v;

        System.out.print("Tahun [" + it.tahun + "]: ");
        v = in.nextLine().trim();
        if (!v.isEmpty()) {
            try { int tBaru = Integer.parseInt(v); if (tBaru >= 0) it.tahun = tBaru; }
            catch (NumberFormatException e) { boxInfo("Format tahun salah."); }
        }

        boxInfo("Item berhasil diperbarui.");
    }

    static void hapus(Scanner in) {
        int id = inputAngkaNonNegatif(in, "Masukkan ID");
        Item it = findById(id);
        if (it == null) { boxInfo("ID tidak ditemukan."); return; }
        System.out.print("Yakin hapus \"" + it.nama + "\"? (y/n): ");
        String y = in.nextLine().trim().toLowerCase();
        if (y.equals("y")) { katalog.remove(it); boxInfo("Data dihapus."); }
        else boxInfo("Dibatalkan.");
    }

    // ====== FILTER ======
    static void filterMenu(Scanner in) {
        System.out.println();
        System.out.println("+-----------------------------+");
        System.out.println("| 1) Berdasarkan Kategori     |");
        System.out.println("| 2) Kembali                  |");
        System.out.println("+-----------------------------+");
        System.out.print("Pilih [1-4] > ");
        String c = in.nextLine().trim();

        switch (c) {
            case "1" -> {
                String kat = inputWajib(in, "Masukkan Kategori");
                List<Item> out = new ArrayList<>();
                for (Item it : katalog)
                    if (it.kategori.equalsIgnoreCase(kat)) out.add(it);
                if (out.isEmpty()) boxInfo("Tidak ada item pada kategori: " + kat);
                else tampilkanTabel(out);
            }
            case "2" -> {
            }
            default -> boxInfo("Pilihan tidak valid.");
        }
    }

    static void tampilkanTabel(List<Item> data) {
        if (data.isEmpty()) { System.out.println("(kosong)"); return; }

        String[] head = {"ID", "Nama", "Kategori", "Ukuran", "Warna", "Brand", "Tahun"};
        int[] w = new int[head.length];
        for (int i = 0; i < head.length; i++) w[i] = head[i].length();

        int CAP = 28;
        for (Item it : data) {
            w[0] = Math.max(w[0], String.valueOf(it.id).length());
            w[1] = Math.max(w[1], it.nama.length());
            w[2] = Math.max(w[2], it.kategori.length());
            w[3] = Math.max(w[3], it.ukuran.length());
            w[4] = Math.max(w[4], it.warna.length());
            w[5] = Math.max(w[5], it.brand.length());
            w[6] = Math.max(w[6], String.valueOf(it.tahun).length());
        }
        for (int i = 0; i < w.length; i++) w[i] = Math.min(w[i], CAP);

        String sep = "+" + repeat("-", w[0]+2) + "+" + repeat("-", w[1]+2) + "+" + repeat("-", w[2]+2)
                   + "+" + repeat("-", w[3]+2) + "+" + repeat("-", w[4]+2) + "+" + repeat("-", w[5]+2)
                   + "+" + repeat("-", w[6]+2) + "+";

        System.out.println(sep);
        System.out.println("| " + pad(head[0], w[0]) + " | " + pad(head[1], w[1]) + " | " +
                           pad(head[2], w[2]) + " | " + pad(head[3], w[3]) + " | " +
                           pad(head[4], w[4]) + " | " + pad(head[5], w[5]) + " | " +
                           pad(head[6], w[6]) + " |");
        System.out.println(sep);

        for (Item it : data) {
            System.out.println("| " + pad(String.valueOf(it.id), w[0]) + " | " +
                               pad(it.nama, w[1]) + " | " +
                               pad(it.kategori, w[2]) + " | " +
                               pad(it.ukuran, w[3]) + " | " +
                               pad(it.warna, w[4]) + " | " +
                               pad(it.brand, w[5]) + " | " +
                               pad(String.valueOf(it.tahun), w[6]) + " |");
        }
        System.out.println(sep);
    }

    static void printBanner() {
        String title = " MANAJEMEN KOLEKSI FASHION ";
        String line = repeat("=", title.length());
        System.out.println("+" + line + "+");
        System.out.println("|" + title + "|");
        System.out.println("+" + line + "+");
        System.out.println("Kelola koleksi pribadi.\n");
    }
    static void printMainMenu() {
        String[] rows = {
            "1) Tambahkan Koleksi Item",
            "2) Tampilkan Daftar Item",
            "3) Cari (ID/Nama)",
            "4) Ubah Data Koleki",
            "5) Hapus Koleksi",
            "6) Filter Koleksi)",
            "7) Keluar dari Program"
        };
        int width = 0;
        for (String r : rows) width = Math.max(width, r.length());
        String top = "+" + repeat("-", width + 2) + "+";
        System.out.println(top);
        for (String r : rows) System.out.println("| " + pad(r, width) + " |");
        System.out.println(top + "\n");
    }
    // Banner untuk Menu Utama (gaya simpel, sama seperti printBanner)
    static void sectionTitle(String text) {
        String line = repeat("-", text.length()+2);
        System.out.println("+" + line + "+");
        System.out.println("| " + text + " |");
        System.out.println("+" + line + "+\n");
    }
    static void boxInfo(String msg) {
        String line = repeat("-", msg.length()+2);
        System.out.println("\n+" + line + "+");
        System.out.println("| " + msg + " |");
        System.out.println("+" + line + "+");
    }
    static void pause(Scanner in) {
        System.out.print("\n(Enter untuk kembali ke menu utama) ");
        in.nextLine();
    }
    static void clearScreen() { // best effort (kalau tidak didukung, tidak apa)
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    // ====== Util (tanpa printf) ======
    static String pad(String s, int w) { // rata kiri, potong bila kepanjangan
        if (s.length() > w) return s.substring(0, w);
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < w) sb.append(' ');
        return sb.toString();
    }
    static String repeat(String s, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(s);
        return sb.toString();
    }
    static String inputWajib(Scanner in, String label) {
        while (true) {
            System.out.print(label + " : ");
            String x = in.nextLine().trim();
            if (!x.isEmpty()) return x;
            boxInfo("Tidak boleh kosong.");
        }
    }
    static int inputAngkaNonNegatif(Scanner in, String label) {
        while (true) {
            System.out.print(label + " : ");
            String x = in.nextLine().trim();
            try { int v = Integer.parseInt(x); if (v >= 0) return v; } catch (Exception ignored) {}
            boxInfo("Masukkan bilangan bulat ≥ 0.");
        }
    }
    static Item findById(int id) {
        for (Item it : katalog) if (it.id == id) return it;
        return null;
    }

    // ====== Seed data awal (10 item campur) ======
    static void seed10Item() {
        katalog.add(new Item(nextId++, "Jaket Denim", "Outer", "M", "Navy", "Levi's", 2022));
        katalog.add(new Item(nextId++, "Sneakers Canvas", "Sepatu", "42", "Putih", "Converse", 2021));
        katalog.add(new Item(nextId++, "Kaos Graphic", "Atasan", "L", "Hitam", "Uniqlo", 2023));
        katalog.add(new Item(nextId++, "Celana Chino", "Bawahan", "32", "Khaki", "H&M", 2022));
        katalog.add(new Item(nextId++, "Dress Batik", "Atasan", "M", "Maroon", "Lokal", 2023));
        katalog.add(new Item(nextId++, "Hoodie Oversize", "Outer", "L", "Abu", "Zara", 2024));
        katalog.add(new Item(nextId++, "Topi Bucket", "Aksesori", "All Size", "Cream", "Columbia", 2020));
        katalog.add(new Item(nextId++, "Rok Plisket", "Bawahan", "M", "Dusty Pink", "Stradivarius", 2023));
        katalog.add(new Item(nextId++, "Cardigan Rajut", "Outer", "S", "Hijau", "Pull&Bear", 2021));
        katalog.add(new Item(nextId++, "Loafers Kulit", "Sepatu", "41", "Cokelat", "Pedro", 2022));
    }
}
